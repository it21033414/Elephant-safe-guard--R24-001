export const TABLE_CONFIG = {
  PER_PAGE: 10,
  PAGE_NO: 1,
};
