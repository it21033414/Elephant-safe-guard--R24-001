// sweetAlertConfig config
export const sweetAlertConfig = {
  preventDuplicates: true,
  includeTitleDuplicates: true,
};

// for testing

// export const sweetAlertConfig = {
//   preventDuplicates: true,
//   includeTitleDuplicates: true,
//   extendedTimeOut: 10000000,
// }
